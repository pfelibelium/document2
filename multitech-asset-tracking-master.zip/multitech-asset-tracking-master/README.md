# MultiConnect Asset Tracking and Monitoring Application
The asset tracking and monitoring application is meant to get you started with developing a complete end-to-end scenario using the MultiTech® MultiConnect™ Conduit and scriptr.io. It showcases many interesting features of scriptr.io, including tracking devices on a map and monitoring them using notifications and alerts. You can use it to jump start your development then start adding more and more devices and features.

[Read more...](https://github.com/scriptrdotio/multitech-asset-tracking/blob/master/asset-tracking/README.md)
